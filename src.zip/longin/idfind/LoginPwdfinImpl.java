package longin.idfind;

import javafx.scene.Parent;
import javafx.scene.control.CheckBox;
import javafx.scene.control.TextField;
import login.service.LoginService;

public class LoginPwdfinImpl implements LoginService {

	public void loginFunc(TextField fxId, TextField fxPwd, CheckBox chkId) {
	}
	public void registerFunc(Parent root) {
	}
	public void idfindFunc(Parent root) {
	}
	public void pwdfindFunc(Parent root) {
		
	}
	public void btnFind(Parent root) {
	}

	public void btnFind(String idf) {
		
	}
	public String idid() {
		return "b";
	}
	public void btnPwd(String pwd) {
		
	}
	public String btnfind() {
		return "a";
	}

}
