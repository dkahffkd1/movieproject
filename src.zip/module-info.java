module movieproject {
	exports member.dao;
	exports login.main;
	exports login.service;
	exports idfind.controller;
	exports member.main;
	exports member.controller;
	exports login.dto;
	exports longin.idfind;
	exports login.controller;
	exports common;
	exports member.dto;
	exports login.dao;
	exports member.service;
	exports login.url;

	requires java.sql;
	requires javafx.base;
	requires javafx.controls;
	requires javafx.fxml;
	requires javafx.graphics;
}